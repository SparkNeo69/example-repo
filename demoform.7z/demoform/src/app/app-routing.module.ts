import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegistrationComponent } from './registration/registration.component';
import { DisplayComponent } from './display/display.component';

const routes: Routes = [
  {path:"", component: RegistrationComponent},
  {path:"regForm", component: RegistrationComponent},
  {path:"display", component: DisplayComponent},

  // { path: '', redirectTo: '/AppComponent', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
