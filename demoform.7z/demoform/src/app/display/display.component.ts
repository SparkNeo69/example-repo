import { Component, OnInit } from '@angular/core';
import { Icustomer } from '../icustomer';
import { Customer } from '../customer';
import { GetCustomersService } from '../get-customers.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  objis: Customer[];
  obji: Customer;
  constructor(private customerservice: GetCustomersService) { }

  ngOnInit() {
        const obji = JSON.parse(localStorage.getItem('obj'));
        console.log(obji);
        document.write(`first name : ${obji.fname}<br>`);
        document.write(`last name : ${obji.lname}<br>`);
        document.write(`Address : ${obji.address}<br>`);
        document.write(`Age : ${obji.age}<br>`);
        document.write(`Email id : ${obji.emailid}<br>`);
        document.write(`Phone no : ${obji.phoneno}<br>`);

        this.objis = this.customerservice.getCustomers().subscribe(data => this.objis = data);
  }

  gatdata() {
    const getname = document.getElementById('no');
    for (const customers of this.objis)
    {
      if ( getname === customers.fname) { }
    }
  }

}
