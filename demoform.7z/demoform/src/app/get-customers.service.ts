import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetCustomersService {

  private jsonURL = 'assets/SampleJson.json';

  constructor(private http: HttpClient) { }

  getCustomers(): Observable< Customer[]> {
    return this.http.get<Customer[]>(this.jsonURL);
  }
}
