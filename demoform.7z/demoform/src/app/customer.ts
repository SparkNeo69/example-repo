
import { Icustomer } from './icustomer';

export class Customer implements Icustomer {
    constructor(
        public fname: string,
        public lname: string,
        public address: string,
        public age: number,
        public emailid: string,
        public phoneno: string
    ){}
}
