import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Icustomer } from '../icustomer';
import { Customer } from '../customer';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regform: FormGroup;
  rsobj: Icustomer;

  constructor(public fc: FormBuilder, public router: Router) { }

  ngOnInit() {
    this.buildregform();
  }

  get registerFormControl() {
    return this.regform.controls;
  }

  buildregform() {
    this.regform = this.fc.group({
      fname: ['', [Validators.required]],
      lname: ['', [Validators.required]],
      age: ['', [Validators.required]],
      address: ['', [Validators.required]],
      emailid: ['', [Validators.required, Validators.email]],
      phoneno: ['', [Validators.required]],
    });
  }

  onSubmit(empForm: FormGroup) {
    if (empForm.invalid) {
      console.log('hello' + empForm.value);
      return;
    }
    this.mapFormValues(empForm);
    if (this.rsobj && empForm.valid) {
      console.log(this.rsobj);
      const localobj = JSON.stringify(this.rsobj);
      localStorage.setItem ('obj', localobj);
    }
    this.dispdisp(empForm);
  }

  mapFormValues(empForm: FormGroup) {
    this.rsobj = new Customer(null, null, null, null, null, null);
    this.rsobj.fname = empForm.controls.fname.value;
    this.rsobj.lname = empForm.controls.lname.value;
    this.rsobj.age = empForm.controls.age.value;
    this.rsobj.address = empForm.controls.address.value;
    this.rsobj.emailid = empForm.controls.emailid.value;
    this.rsobj.phoneno = empForm.controls.phoneno.value;
  }

  dispdisp(empForm: FormGroup) {
      const x = document.getElementById('hdisp');
      if (empForm.valid) {
        x.style.display = 'block';
       }

  }

  go() {
    this.router.navigate(['/display']);
  }

}
