export interface Icustomer {
        fname: string;
        lname: string;
        address: string;
        age: number;
        emailid: string;
        phoneno: string;
}
